"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { RotateCcw, Info, Play, Pause, ChevronLeft, ChevronRight } from "lucide-react"
import { AutomataConverter } from "@/lib/automata-converter"
import { AutomataDiagram } from "@/components/automata-diagram"
import { TransitionTable } from "@/components/transition-table"
import { ProblemSelector } from "@/components/problem-selector"
import { predefinedProblems } from "@/lib/predefined-problems"
import type { Automaton, ConversionStep, ConversionMode } from "@/lib/types"

const conversionModes = [
  {
    value: "NFA_TO_DFA_SUBSET",
    label: "NFA → DFA (Subset Construction)",
    description: "Standard subset construction algorithm",
  },
  { value: "NFA_TO_DFA_POWERSET", label: "NFA → DFA (Powerset Method)", description: "Alternative powerset approach" },
  {
    value: "EPSILON_NFA_TO_NFA_CLOSURE",
    label: "ε-NFA → NFA (ε-Closure)",
    description: "Remove ε-transitions using closure",
  },
  {
    value: "EPSILON_NFA_TO_DFA_DIRECT",
    label: "ε-NFA → DFA (Direct)",
    description: "Direct conversion without intermediate NFA",
  },
  { value: "EPSILON_NFA_TO_DFA_TWO_PHASE", label: "ε-NFA → DFA (Two-Phase)", description: "First to NFA, then to DFA" },
  { value: "NFA_MINIMIZE_DFA", label: "NFA → Minimal DFA", description: "Convert and minimize the resulting DFA" },
  { value: "DFA_TO_REGEX", label: "DFA → Regular Expression", description: "Convert DFA to equivalent regex" },
  { value: "REGEX_TO_NFA", label: "Regex → NFA", description: "Thompson's construction algorithm" },
  { value: "NFA_UNION", label: "NFA Union Construction", description: "Create NFA for union of two languages" },
  { value: "NFA_INTERSECTION", label: "NFA Intersection", description: "Create NFA for intersection of languages" },
] as const

export default function AutomataSimulator() {
  const [mode, setMode] = useState<ConversionMode>("NFA_TO_DFA_SUBSET")
  const [selectedProblem, setSelectedProblem] = useState<string>("")
  const [originalAutomaton, setOriginalAutomaton] = useState<Automaton | null>(null)
  const [conversionSteps, setConversionSteps] = useState<ConversionStep[]>([])
  const [currentStep, setCurrentStep] = useState(0)
  const [isConverting, setIsConverting] = useState(false)
  const [isAutoPlaying, setIsAutoPlaying] = useState(false)

  const converter = new AutomataConverter()

  useEffect(() => {
    if (selectedProblem && predefinedProblems[selectedProblem]) {
      setOriginalAutomaton(predefinedProblems[selectedProblem])
      setConversionSteps([])
      setCurrentStep(0)
      setIsConverting(false)
      setIsAutoPlaying(false)
    }
  }, [selectedProblem])

  const handleConvert = async () => {
    if (!originalAutomaton) return

    setIsConverting(true)
    const steps = converter.convert(originalAutomaton, mode)
    setConversionSteps(steps)
    setCurrentStep(0)
  }

  const handleReset = () => {
    setConversionSteps([])
    setCurrentStep(0)
    setIsConverting(false)
    setIsAutoPlaying(false)
  }

  const handleNextStep = () => {
    if (currentStep < conversionSteps.length - 1) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handlePrevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleAutoPlay = () => {
    setIsAutoPlaying(!isAutoPlaying)
  }

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isAutoPlaying && currentStep < conversionSteps.length - 1) {
      interval = setInterval(() => {
        setCurrentStep((prev) => {
          if (prev >= conversionSteps.length - 1) {
            setIsAutoPlaying(false)
            return prev
          }
          return prev + 1
        })
      }, 2500)
    }
    return () => clearInterval(interval)
  }, [isAutoPlaying, currentStep, conversionSteps.length])

  const currentStepData = conversionSteps[currentStep]
  const currentAutomaton = currentStepData?.automaton || originalAutomaton
  const selectedModeInfo = conversionModes.find((m) => m.value === mode)

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <Card className="border-2 border-indigo-200">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold text-indigo-800 mb-2">
              🔄 Multi-Mode Automata Conversion Simulator
            </CardTitle>
            <p className="text-gray-600 text-lg">10 Different Conversion Modes with Step-by-Step Visualization</p>
            <div className="flex justify-center gap-4 mt-4">
              <Badge variant="outline" className="text-sm">
                10 Conversion Modes
              </Badge>
              <Badge variant="outline" className="text-sm">
                5 NFA Problems
              </Badge>
              <Badge variant="outline" className="text-sm">
                5 ε-NFA Problems
              </Badge>
            </div>
          </CardHeader>
        </Card>

        {/* Controls */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-lg">🎯 Select Conversion Mode</CardTitle>
              <p className="text-sm text-gray-600">Choose from 10 different conversion algorithms</p>
            </CardHeader>
            <CardContent>
              <Select value={mode} onValueChange={(value: ConversionMode) => setMode(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {conversionModes.map((modeOption) => (
                    <SelectItem key={modeOption.value} value={modeOption.value}>
                      <div>
                        <div className="font-medium">{modeOption.label}</div>
                        <div className="text-xs text-gray-500">{modeOption.description}</div>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedModeInfo && (
                <div className="mt-2 p-3 bg-blue-50 rounded-lg">
                  <p className="text-sm text-blue-800">{selectedModeInfo.description}</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">📋 Select Problem</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <ProblemSelector selectedProblem={selectedProblem} onProblemSelect={setSelectedProblem} mode={mode} />
              <div className="space-y-2">
                <Button onClick={handleConvert} disabled={!originalAutomaton || isConverting} className="w-full">
                  🚀 Start Conversion
                </Button>
                <Button onClick={handleReset} variant="outline" className="w-full bg-transparent">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Reset
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Step Controls */}
        {conversionSteps.length > 0 && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">
                  🔄 Step {currentStep + 1} of {conversionSteps.length}
                </CardTitle>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" onClick={handlePrevStep} disabled={currentStep === 0}>
                    <ChevronLeft className="w-4 h-4" />
                    Previous
                  </Button>
                  <Button variant={isAutoPlaying ? "default" : "outline"} size="sm" onClick={handleAutoPlay}>
                    {isAutoPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                    {isAutoPlaying ? "Pause" : "Auto"}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleNextStep}
                    disabled={currentStep === conversionSteps.length - 1}
                  >
                    Next
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Step Description */}
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h3 className="font-semibold text-base text-blue-900 mb-2">{currentStepData.description}</h3>
                  <p className="text-sm text-blue-800">{currentStepData.explanation}</p>
                  {currentStepData.algorithm && (
                    <div className="mt-2 p-2 bg-blue-100 rounded text-xs font-mono text-blue-900">
                      Algorithm: {currentStepData.algorithm}
                    </div>
                  )}
                </div>

                {/* Progress Bar */}
                <div className="space-y-2">
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>Progress</span>
                    <span>{Math.round(((currentStep + 1) / conversionSteps.length) * 100)}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div
                      className="bg-gradient-to-r from-blue-500 to-blue-600 h-3 rounded-full transition-all duration-500"
                      style={{ width: `${((currentStep + 1) / conversionSteps.length) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Step Highlights */}
                <div className="flex flex-wrap gap-3">
                  {currentStepData.newStates && currentStepData.newStates.length > 0 && (
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-green-700 font-medium">New States:</span>
                      <div className="flex gap-1">
                        {currentStepData.newStates.map((state) => (
                          <Badge key={state} variant="secondary" className="text-xs bg-green-100 text-green-800">
                            {state}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {currentStepData.highlightedStates.length > 0 && (
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-yellow-700 font-medium">Active States:</span>
                      <div className="flex gap-1">
                        {currentStepData.highlightedStates.map((state) => (
                          <Badge key={state} variant="secondary" className="text-xs bg-yellow-100 text-yellow-800">
                            {state}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Main Content */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          {/* Diagram */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Info className="w-5 h-5" />
                {conversionSteps.length === 0
                  ? `Original ${originalAutomaton?.type || "Automaton"}`
                  : currentStep === conversionSteps.length - 1
                    ? "Final Result"
                    : `Step ${currentStep + 1} Result`}
              </CardTitle>
              {originalAutomaton && <p className="text-sm text-gray-600">{originalAutomaton.name}</p>}
            </CardHeader>
            <CardContent>
              <AutomataDiagram
                automaton={currentAutomaton}
                highlightedStates={currentStepData?.highlightedStates || []}
                highlightedTransitions={currentStepData?.highlightedTransitions || []}
              />
            </CardContent>
          </Card>

          {/* Transition Table */}
          <Card>
            <CardHeader>
              <CardTitle>📊 Transition Table</CardTitle>
              <p className="text-sm text-gray-600">
                {conversionSteps.length === 0
                  ? "Original automaton structure"
                  : `Step ${currentStep + 1} automaton structure`}
              </p>
            </CardHeader>
            <CardContent>
              <TransitionTable
                automaton={currentAutomaton}
                highlightedStates={currentStepData?.highlightedStates || []}
              />
            </CardContent>
          </Card>
        </div>

        {/* Algorithm Summary */}
        {conversionSteps.length > 0 && (
          <Card className="border-2 border-green-200">
            <CardHeader>
              <CardTitle className="text-lg text-green-800">🎯 Conversion Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">{conversionSteps.length}</div>
                  <div className="text-sm text-blue-800">Total Steps</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">{originalAutomaton?.states.length || 0}</div>
                  <div className="text-sm text-green-800">Original States</div>
                </div>
                <div className="text-center p-4 bg-orange-50 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">
                    {currentStepData?.automaton.states.length || 0}
                  </div>
                  <div className="text-sm text-orange-800">Current States</div>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">
                    {Math.round(((currentStep + 1) / conversionSteps.length) * 100)}%
                  </div>
                  <div className="text-sm text-purple-800">Progress</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
