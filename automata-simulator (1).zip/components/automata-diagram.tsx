"use client"

import { useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { ZoomIn, ZoomOut, RotateCcw } from "lucide-react"
import type { Automaton } from "@/lib/types"

interface AutomataDiagramProps {
  automaton: Automaton | null
  highlightedStates?: string[]
  highlightedTransitions?: Array<{ from: string; to: string; symbol: string }>
}

export function AutomataDiagram({
  automaton,
  highlightedStates = [],
  highlightedTransitions = [],
}: AutomataDiagramProps) {
  const svgRef = useRef<SVGSVGElement>(null)
  const [zoom, setZoom] = useState(1)
  const [pan, setPan] = useState({ x: 0, y: 0 })
  const [selectedState, setSelectedState] = useState<string | null>(null)

  if (!automaton) {
    return (
      <div className="flex items-center justify-center h-64 text-gray-500">Select a problem to view the automaton</div>
    )
  }

  // Calculate positions for states in a circle with better spacing
  const statePositions = calculateStatePositions(automaton.states)

  const handleStateClick = (state: string) => {
    setSelectedState(selectedState === state ? null : state)
  }

  const handleZoomIn = () => setZoom((prev) => Math.min(prev * 1.2, 3))
  const handleZoomOut = () => setZoom((prev) => Math.max(prev / 1.2, 0.3))
  const handleReset = () => {
    setZoom(1)
    setPan({ x: 0, y: 0 })
    setSelectedState(null)
  }

  return (
    <div className="relative">
      {/* Controls */}
      <div className="absolute top-2 right-2 z-10 flex gap-1">
        <Button size="sm" variant="outline" onClick={handleZoomIn}>
          <ZoomIn className="w-4 h-4" />
        </Button>
        <Button size="sm" variant="outline" onClick={handleZoomOut}>
          <ZoomOut className="w-4 h-4" />
        </Button>
        <Button size="sm" variant="outline" onClick={handleReset}>
          <RotateCcw className="w-4 h-4" />
        </Button>
      </div>

      {/* SVG Diagram */}
      <svg
        ref={svgRef}
        width="100%"
        height="450"
        viewBox={`${-250 + pan.x} ${-250 + pan.y} ${500 / zoom} ${500 / zoom}`}
        className="border rounded-lg bg-white"
      >
        <defs>
          <marker id="arrowhead" markerWidth="6" markerHeight="4" refX="5" refY="2" orient="auto">
            <polygon points="0 0, 6 2, 0 4" fill="#374151" />
          </marker>
          <marker id="arrowhead-highlighted" markerWidth="6" markerHeight="4" refX="5" refY="2" orient="auto">
            <polygon points="0 0, 6 2, 0 4" fill="#dc2626" />
          </marker>
        </defs>

        {/* Transitions */}
        {Object.entries(automaton.transitions).map(([fromState, transitions]) =>
          Object.entries(transitions).map(([symbol, toStates]) =>
            toStates.map((toState, index) => {
              const isHighlighted = highlightedTransitions.some(
                (t) => t.from === fromState && t.to === toState && t.symbol === symbol,
              )
              return (
                <TransitionArrow
                  key={`${fromState}-${symbol}-${toState}-${index}`}
                  from={statePositions[fromState]}
                  to={statePositions[toState]}
                  symbol={symbol}
                  isHighlighted={isHighlighted}
                  isSelfLoop={fromState === toState}
                />
              )
            }),
          ),
        )}

        {/* States */}
        {automaton.states.map((state) => {
          const pos = statePositions[state]
          const isHighlighted = highlightedStates.includes(state)
          const isSelected = selectedState === state
          const isFinal = automaton.finalStates.includes(state)
          const isStart = state === automaton.startState

          return (
            <g key={state}>
              {/* Start state arrow */}
              {isStart && (
                <>
                  <line
                    x1={pos.x - 60}
                    y1={pos.y}
                    x2={pos.x - 30}
                    y2={pos.y}
                    stroke="#374151"
                    strokeWidth="1.5"
                    markerEnd="url(#arrowhead)"
                  />
                  <text x={pos.x - 75} y={pos.y + 5} textAnchor="middle" className="text-xs fill-gray-600">
                    start
                  </text>
                </>
              )}

              {/* State circle */}
              <circle
                cx={pos.x}
                cy={pos.y}
                r="25"
                fill={isHighlighted ? "#fef3c7" : isSelected ? "#dbeafe" : "white"}
                stroke={isHighlighted ? "#f59e0b" : isSelected ? "#3b82f6" : "#374151"}
                strokeWidth={isHighlighted ? "3" : isSelected ? "2" : "2"}
                className="cursor-pointer hover:fill-gray-50"
                onClick={() => handleStateClick(state)}
              />

              {/* Final state double circle */}
              {isFinal && (
                <circle
                  cx={pos.x}
                  cy={pos.y}
                  r="20"
                  fill="none"
                  stroke={isHighlighted ? "#f59e0b" : isSelected ? "#3b82f6" : "#374151"}
                  strokeWidth={isHighlighted ? "2" : "1.5"}
                />
              )}

              {/* State label */}
              <text
                x={pos.x}
                y={pos.y + 5}
                textAnchor="middle"
                className="text-sm font-medium fill-gray-800 pointer-events-none"
              >
                {state}
              </text>
            </g>
          )
        })}
      </svg>

      {/* State Info Panel */}
      {selectedState && (
        <div className="absolute bottom-2 left-2 bg-white p-3 rounded-lg shadow-lg border max-w-xs">
          <h4 className="font-semibold text-sm mb-2">State: {selectedState}</h4>
          <div className="space-y-1 text-xs">
            <div>
              Type: {automaton.startState === selectedState ? "Start" : ""}{" "}
              {automaton.finalStates.includes(selectedState) ? "Final" : "Regular"}
            </div>
            <div>Outgoing transitions:</div>
            <ul className="ml-2 space-y-1">
              {Object.entries(automaton.transitions[selectedState] || {}).map(([symbol, states]) => (
                <li key={symbol}>
                  {symbol === "" ? "ε" : symbol} → {states.join(", ")}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  )
}

function calculateStatePositions(states: string[]): Record<string, { x: number; y: number }> {
  const positions: Record<string, { x: number; y: number }> = {}
  const radius = 150
  const centerX = 0
  const centerY = 0

  if (states.length <= 3) {
    // For small number of states, use horizontal layout
    states.forEach((state, index) => {
      positions[state] = {
        x: (index - (states.length - 1) / 2) * 120,
        y: 0,
      }
    })
  } else {
    // For more states, use circular layout
    states.forEach((state, index) => {
      const angle = (2 * Math.PI * index) / states.length - Math.PI / 2
      positions[state] = {
        x: centerX + radius * Math.cos(angle),
        y: centerY + radius * Math.sin(angle),
      }
    })
  }

  return positions
}

function TransitionArrow({
  from,
  to,
  symbol,
  isHighlighted,
  isSelfLoop,
}: {
  from: { x: number; y: number }
  to: { x: number; y: number }
  symbol: string
  isHighlighted: boolean
  isSelfLoop: boolean
}) {
  if (isSelfLoop) {
    // Smaller self-loop that doesn't cover the diagram
    const loopRadius = 15
    const loopX = from.x + 20
    const loopY = from.y - 20

    return (
      <g>
        <circle
          cx={loopX}
          cy={loopY}
          r={loopRadius}
          fill="none"
          stroke={isHighlighted ? "#dc2626" : "#374151"}
          strokeWidth={isHighlighted ? "2" : "1"}
          markerEnd={isHighlighted ? "url(#arrowhead-highlighted)" : "url(#arrowhead)"}
        />
        <text
          x={loopX + 10}
          y={loopY - 10}
          textAnchor="middle"
          className={`text-xs ${isHighlighted ? "fill-red-600 font-semibold" : "fill-gray-600"}`}
        >
          {symbol === "" ? "ε" : symbol}
        </text>
      </g>
    )
  }

  // Calculate arrow position with much shorter arrows
  const dx = to.x - from.x
  const dy = to.y - from.y
  const length = Math.sqrt(dx * dx + dy * dy)
  const unitX = dx / length
  const unitY = dy / length

  // Start and end points closer to state circles
  const startX = from.x + unitX * 27
  const startY = from.y + unitY * 27
  const endX = to.x - unitX * 30
  const endY = to.y - unitY * 30

  // Label position
  const midX = (startX + endX) / 2
  const midY = (startY + endY) / 2

  return (
    <g>
      <line
        x1={startX}
        y1={startY}
        x2={endX}
        y2={endY}
        stroke={isHighlighted ? "#dc2626" : "#374151"}
        strokeWidth={isHighlighted ? "2" : "1"}
        markerEnd={isHighlighted ? "url(#arrowhead-highlighted)" : "url(#arrowhead)"}
      />
      <text
        x={midX}
        y={midY - 5}
        textAnchor="middle"
        className={`text-xs ${isHighlighted ? "fill-red-600 font-semibold" : "fill-gray-600"}`}
      >
        {symbol === "" ? "ε" : symbol}
      </text>
    </g>
  )
}
