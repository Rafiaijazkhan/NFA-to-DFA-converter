"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ChevronDown, ChevronRight, Play } from "lucide-react"
import { TransitionTable } from "./transition-table"
import type { Automaton, ConversionMode } from "@/lib/types"

interface ConversionExample {
  id: string
  title: string
  description: string
  originalAutomaton: Automaton
  convertedAutomaton: Automaton
  steps: Array<{
    stepNumber: number
    description: string
    explanation: string
    stateChanges: string[]
    transitionChanges: string[]
  }>
  conversionType: ConversionMode
}

const conversionExamples: ConversionExample[] = [
  // NFA to DFA Examples (5)
  {
    id: "nfa-dfa-1",
    title: "NFA→DFA: Binary strings ending in '01'",
    description: "Convert NFA that accepts binary strings ending in '01' to equivalent DFA",
    conversionType: "NFA_TO_DFA",
    originalAutomaton: {
      states: ["q0", "q1", "q2"],
      alphabet: ["0", "1"],
      transitions: {
        q0: { "0": ["q0", "q1"], "1": ["q0"] },
        q1: { "0": [], "1": ["q2"] },
        q2: { "0": [], "1": [] },
      },
      startState: "q0",
      finalStates: ["q2"],
      type: "NFA",
    },
    convertedAutomaton: {
      states: ["{q0}", "{q0,q1}", "{q0,q2}"],
      alphabet: ["0", "1"],
      transitions: {
        "{q0}": { "0": ["{q0,q1}"], "1": ["{q0}"] },
        "{q0,q1}": { "0": ["{q0,q1}"], "1": ["{q0,q2}"] },
        "{q0,q2}": { "0": ["{q0,q1}"], "1": ["{q0}"] },
      },
      startState: "{q0}",
      finalStates: ["{q0,q2}"],
      type: "DFA",
    },
    steps: [
      {
        stepNumber: 1,
        description: "Initialize with start state {q0}",
        explanation: "Create initial DFA state from NFA start state q0",
        stateChanges: ["Added state {q0}"],
        transitionChanges: [],
      },
      {
        stepNumber: 2,
        description: "Process {q0} on symbol '0'",
        explanation: "δ(q0, 0) = {q0, q1}, so create new state {q0,q1}",
        stateChanges: ["Added state {q0,q1}"],
        transitionChanges: ["Added transition {q0} --0--> {q0,q1}"],
      },
    ],
  },

  {
    id: "nfa-dfa-2",
    title: "NFA→DFA: Contains substring '101'",
    description: "Convert NFA that accepts strings containing '101' to DFA",
    conversionType: "NFA_TO_DFA",
    originalAutomaton: {
      states: ["q0", "q1", "q2", "q3"],
      alphabet: ["0", "1"],
      transitions: {
        q0: { "0": ["q0"], "1": ["q0", "q1"] },
        q1: { "0": ["q2"], "1": ["q0"] },
        q2: { "0": ["q0"], "1": ["q3"] },
        q3: { "0": ["q3"], "1": ["q3"] },
      },
      startState: "q0",
      finalStates: ["q3"],
      type: "NFA",
    },
    convertedAutomaton: {
      states: ["{q0}", "{q0,q1}", "{q0,q2}", "{q0,q1,q3}", "{q0,q3}"],
      alphabet: ["0", "1"],
      transitions: {
        "{q0}": { "0": ["{q0}"], "1": ["{q0,q1}"] },
        "{q0,q1}": { "0": ["{q0,q2}"], "1": ["{q0,q1}"] },
        "{q0,q2}": { "0": ["{q0}"], "1": ["{q0,q1,q3}"] },
        "{q0,q1,q3}": { "0": ["{q0,q2}"], "1": ["{q0,q1,q3}"] },
        "{q0,q3}": { "0": ["{q0,q3}"], "1": ["{q0,q1,q3}"] },
      },
      startState: "{q0}",
      finalStates: ["{q0,q1,q3}", "{q0,q3}"],
      type: "DFA",
    },
    steps: [
      {
        stepNumber: 1,
        description: "Initialize with {q0}",
        explanation: "Start with the initial state of the NFA",
        stateChanges: ["Added state {q0}"],
        transitionChanges: [],
      },
    ],
  },

  {
    id: "nfa-dfa-3",
    title: "NFA→DFA: Even number of 0s",
    description: "Convert NFA accepting strings with even number of 0s",
    conversionType: "NFA_TO_DFA",
    originalAutomaton: {
      states: ["q0", "q1", "q2"],
      alphabet: ["0", "1"],
      transitions: {
        q0: { "0": ["q1", "q2"], "1": ["q0"] },
        q1: { "0": ["q0"], "1": ["q1"] },
        q2: { "0": ["q0"], "1": ["q2"] },
      },
      startState: "q0",
      finalStates: ["q0"],
      type: "NFA",
    },
    convertedAutomaton: {
      states: ["{q0}", "{q0,q1,q2}", "{q1,q2}"],
      alphabet: ["0", "1"],
      transitions: {
        "{q0}": { "0": ["{q1,q2}"], "1": ["{q0}"] },
        "{q1,q2}": { "0": ["{q0}"], "1": ["{q1,q2}"] },
        "{q0,q1,q2}": { "0": ["{q0,q1,q2}"], "1": ["{q0,q1,q2}"] },
      },
      startState: "{q0}",
      finalStates: ["{q0}", "{q0,q1,q2}"],
      type: "DFA",
    },
    steps: [
      {
        stepNumber: 1,
        description: "Initialize with {q0}",
        explanation: "Start state accepts even number of 0s (zero is even)",
        stateChanges: ["Added state {q0}"],
        transitionChanges: [],
      },
    ],
  },

  {
    id: "nfa-dfa-4",
    title: "NFA→DFA: Starts and ends with same symbol",
    description: "Convert NFA for strings that start and end with same symbol",
    conversionType: "NFA_TO_DFA",
    originalAutomaton: {
      states: ["q0", "q1", "q2", "q3", "q4"],
      alphabet: ["a", "b"],
      transitions: {
        q0: { a: ["q1"], b: ["q3"] },
        q1: { a: ["q1", "q2"], b: ["q1"] },
        q2: { a: [], b: [] },
        q3: { a: ["q3"], b: ["q3", "q4"] },
        q4: { a: [], b: [] },
      },
      startState: "q0",
      finalStates: ["q2", "q4"],
      type: "NFA",
    },
    convertedAutomaton: {
      states: ["{q0}", "{q1}", "{q3}", "{q1,q2}", "{q3,q4}"],
      alphabet: ["a", "b"],
      transitions: {
        "{q0}": { a: ["{q1}"], b: ["{q3}"] },
        "{q1}": { a: ["{q1,q2}"], b: ["{q1}"] },
        "{q3}": { a: ["{q3}"], b: ["{q3,q4}"] },
        "{q1,q2}": { a: [], b: ["{q1}"] },
        "{q3,q4}": { a: ["{q3}"], b: [] },
      },
      startState: "{q0}",
      finalStates: ["{q1,q2}", "{q3,q4}"],
      type: "DFA",
    },
    steps: [
      {
        stepNumber: 1,
        description: "Initialize with {q0}",
        explanation: "Start state branches to 'a' path or 'b' path",
        stateChanges: ["Added state {q0}"],
        transitionChanges: [],
      },
    ],
  },

  {
    id: "nfa-dfa-5",
    title: "NFA→DFA: Length multiple of 3",
    description: "Convert NFA accepting strings with length multiple of 3",
    conversionType: "NFA_TO_DFA",
    originalAutomaton: {
      states: ["q0", "q1", "q2"],
      alphabet: ["0", "1"],
      transitions: {
        q0: { "0": ["q0", "q1"], "1": ["q0", "q1"] },
        q1: { "0": ["q2"], "1": ["q2"] },
        q2: { "0": ["q0"], "1": ["q0"] },
      },
      startState: "q0",
      finalStates: ["q0"],
      type: "NFA",
    },
    convertedAutomaton: {
      states: ["{q0}", "{q0,q1}", "{q0,q2}"],
      alphabet: ["0", "1"],
      transitions: {
        "{q0}": { "0": ["{q0,q1}"], "1": ["{q0,q1}"] },
        "{q0,q1}": { "0": ["{q0,q2}"], "1": ["{q0,q2}"] },
        "{q0,q2}": { "0": ["{q0,q1}"], "1": ["{q0,q1}"] },
      },
      startState: "{q0}",
      finalStates: ["{q0}", "{q0,q2}"],
      type: "DFA",
    },
    steps: [
      {
        stepNumber: 1,
        description: "Initialize with {q0}",
        explanation: "Start state represents length 0 (multiple of 3)",
        stateChanges: ["Added state {q0}"],
        transitionChanges: [],
      },
    ],
  },

  // ε-NFA to NFA Examples (3)
  {
    id: "epsilon-nfa-nfa-1",
    title: "ε-NFA→NFA: Optional 'a' in middle",
    description: "Remove ε-transitions from NFA with optional middle character",
    conversionType: "EPSILON_NFA_TO_NFA",
    originalAutomaton: {
      states: ["q0", "q1", "q2", "q3"],
      alphabet: ["a", "b", ""],
      transitions: {
        q0: { b: ["q0"], "": ["q1", "q3"] },
        q1: { a: ["q2"] },
        q2: { b: ["q2"], "": ["q3"] },
        q3: { b: ["q3"] },
      },
      startState: "q0",
      finalStates: ["q3"],
      type: "EPSILON_NFA",
    },
    convertedAutomaton: {
      states: ["q0", "q1", "q2", "q3"],
      alphabet: ["a", "b"],
      transitions: {
        q0: { a: ["q2"], b: ["q0", "q3"] },
        q1: { a: ["q2"], b: [] },
        q2: { a: [], b: ["q2", "q3"] },
        q3: { a: [], b: ["q3"] },
      },
      startState: "q0",
      finalStates: ["q0", "q3"],
      type: "NFA",
    },
    steps: [
      {
        stepNumber: 1,
        description: "Compute ε-closures",
        explanation: "Calculate which states are reachable via ε-transitions",
        stateChanges: [],
        transitionChanges: [],
      },
    ],
  },

  {
    id: "epsilon-nfa-nfa-2",
    title: "ε-NFA→NFA: Union of languages",
    description: "Remove ε-transitions from union construction",
    conversionType: "EPSILON_NFA_TO_NFA",
    originalAutomaton: {
      states: ["q0", "q1", "q2", "q3", "q4", "q5"],
      alphabet: ["a", "b", "c", "d", ""],
      transitions: {
        q0: { "": ["q1", "q3"] },
        q1: { a: ["q1"], "": ["q2"] },
        q2: { b: ["q2"], "": ["q5"] },
        q3: { c: ["q3"], "": ["q4"] },
        q4: { d: ["q4"], "": ["q5"] },
        q5: {},
      },
      startState: "q0",
      finalStates: ["q5"],
      type: "EPSILON_NFA",
    },
    convertedAutomaton: {
      states: ["q0", "q1", "q2", "q3", "q4", "q5"],
      alphabet: ["a", "b", "c", "d"],
      transitions: {
        q0: { a: ["q1"], b: ["q2"], c: ["q3"], d: ["q4"] },
        q1: { a: ["q1"], b: ["q2", "q5"] },
        q2: { b: ["q2"], a: [], c: [], d: [] },
        q3: { c: ["q3"], d: ["q4"] },
        q4: { d: ["q4"], a: [], b: [], c: [] },
        q5: { a: [], b: [], c: [], d: [] },
      },
      startState: "q0",
      finalStates: ["q0", "q1", "q2", "q3", "q4", "q5"],
      type: "NFA",
    },
    steps: [
      {
        stepNumber: 1,
        description: "Compute ε-closures for union",
        explanation: "Handle ε-transitions that create language union",
        stateChanges: [],
        transitionChanges: [],
      },
    ],
  },

  // ε-NFA to DFA Examples (2)
  {
    id: "epsilon-nfa-dfa-1",
    title: "ε-NFA→DFA: Kleene star pattern",
    description: "Two-phase conversion: ε-NFA → NFA → DFA for (ab)*",
    conversionType: "EPSILON_NFA_TO_DFA",
    originalAutomaton: {
      states: ["q0", "q1", "q2"],
      alphabet: ["a", "b", ""],
      transitions: {
        q0: { "": ["q1", "q2"] },
        q1: { a: ["q1"], b: ["q1"], "": ["q2"] },
        q2: { "": ["q0"] },
      },
      startState: "q0",
      finalStates: ["q2"],
      type: "EPSILON_NFA",
    },
    convertedAutomaton: {
      states: ["{q0,q1,q2}", "{q0,q1,q2}"],
      alphabet: ["a", "b"],
      transitions: {
        "{q0,q1,q2}": { a: ["{q0,q1,q2}"], b: ["{q0,q1,q2}"] },
      },
      startState: "{q0,q1,q2}",
      finalStates: ["{q0,q1,q2}"],
      type: "DFA",
    },
    steps: [
      {
        stepNumber: 1,
        description: "Phase 1: Remove ε-transitions",
        explanation: "First convert ε-NFA to NFA by eliminating ε-transitions",
        stateChanges: [],
        transitionChanges: [],
      },
      {
        stepNumber: 2,
        description: "Phase 2: Apply subset construction",
        explanation: "Then convert resulting NFA to DFA using subset construction",
        stateChanges: [],
        transitionChanges: [],
      },
    ],
  },

  {
    id: "epsilon-nfa-dfa-2",
    title: "ε-NFA→DFA: Complex multi-path",
    description: "Two-phase conversion for complex ε-NFA with multiple paths",
    conversionType: "EPSILON_NFA_TO_DFA",
    originalAutomaton: {
      states: ["q0", "q1", "q2", "q3", "q4", "q5"],
      alphabet: ["a", "b", "c", "d", ""],
      transitions: {
        q0: { "": ["q1"], a: ["q0"], b: ["q0"] },
        q1: { a: ["q1"], b: ["q1"], c: ["q2"], "": ["q2"] },
        q2: { c: ["q3"] },
        q3: { "": ["q4", "q5"] },
        q4: { d: ["q5"] },
        q5: {},
      },
      startState: "q0",
      finalStates: ["q5"],
      type: "EPSILON_NFA",
    },
    convertedAutomaton: {
      states: ["{q0,q1,q2}", "{q0,q1,q2,q3,q4,q5}"],
      alphabet: ["a", "b", "c", "d"],
      transitions: {
        "{q0,q1,q2}": {
          a: ["{q0,q1,q2}"],
          b: ["{q0,q1,q2}"],
          c: ["{q0,q1,q2,q3,q4,q5}"],
          d: [],
        },
        "{q0,q1,q2,q3,q4,q5}": {
          a: ["{q0,q1,q2}"],
          b: ["{q0,q1,q2}"],
          c: ["{q0,q1,q2,q3,q4,q5}"],
          d: ["{q0,q1,q2,q3,q4,q5}"],
        },
      },
      startState: "{q0,q1,q2}",
      finalStates: ["{q0,q1,q2,q3,q4,q5}"],
      type: "DFA",
    },
    steps: [
      {
        stepNumber: 1,
        description: "Phase 1: ε-closure computation",
        explanation: "Compute ε-closures and eliminate ε-transitions",
        stateChanges: [],
        transitionChanges: [],
      },
      {
        stepNumber: 2,
        description: "Phase 2: Subset construction",
        explanation: "Apply subset construction to get final DFA",
        stateChanges: [],
        transitionChanges: [],
      },
    ],
  },
]

interface ConversionExamplesProps {
  onLoadExample: (example: ConversionExample) => void
}

export function ConversionExamples({ onLoadExample }: ConversionExamplesProps) {
  const [expandedExample, setExpandedExample] = useState<string | null>(null)

  const toggleExample = (exampleId: string) => {
    setExpandedExample(expandedExample === exampleId ? null : exampleId)
  }

  // Group examples by conversion type
  const nfaToDfaExamples = conversionExamples.filter((ex) => ex.conversionType === "NFA_TO_DFA")
  const epsilonNfaToNfaExamples = conversionExamples.filter((ex) => ex.conversionType === "EPSILON_NFA_TO_NFA")
  const epsilonNfaToDfaExamples = conversionExamples.filter((ex) => ex.conversionType === "EPSILON_NFA_TO_DFA")

  return (
    <div className="space-y-6">
      <Card className="border-2 border-purple-200">
        <CardHeader>
          <CardTitle className="text-xl text-purple-800">🔄 10 Conversion Examples Library</CardTitle>
          <p className="text-purple-600">
            Comprehensive collection of automata conversion examples with detailed analysis
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{nfaToDfaExamples.length}</div>
              <div className="text-sm text-blue-800">NFA → DFA Examples</div>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{epsilonNfaToNfaExamples.length}</div>
              <div className="text-sm text-green-800">ε-NFA → NFA Examples</div>
            </div>
            <div className="text-center p-4 bg-orange-50 rounded-lg">
              <div className="text-2xl font-bold text-orange-600">{epsilonNfaToDfaExamples.length}</div>
              <div className="text-sm text-orange-800">ε-NFA → DFA Examples</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* NFA to DFA Examples */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg text-blue-800">🔵 NFA → DFA Conversions (5 Examples)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {nfaToDfaExamples.map((example) => (
              <ExampleCard
                key={example.id}
                example={example}
                isExpanded={expandedExample === example.id}
                onToggle={() => toggleExample(example.id)}
                onLoad={() => onLoadExample(example)}
              />
            ))}
          </div>
        </CardContent>
      </Card>

      {/* ε-NFA to NFA Examples */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg text-green-800">🟢 ε-NFA → NFA Conversions (3 Examples)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {epsilonNfaToNfaExamples.map((example) => (
              <ExampleCard
                key={example.id}
                example={example}
                isExpanded={expandedExample === example.id}
                onToggle={() => toggleExample(example.id)}
                onLoad={() => onLoadExample(example)}
              />
            ))}
          </div>
        </CardContent>
      </Card>

      {/* ε-NFA to DFA Examples */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg text-orange-800">🟠 ε-NFA → DFA Conversions (2 Examples)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {epsilonNfaToDfaExamples.map((example) => (
              <ExampleCard
                key={example.id}
                example={example}
                isExpanded={expandedExample === example.id}
                onToggle={() => toggleExample(example.id)}
                onLoad={() => onLoadExample(example)}
              />
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function ExampleCard({
  example,
  isExpanded,
  onToggle,
  onLoad,
}: {
  example: ConversionExample
  isExpanded: boolean
  onToggle: () => void
  onLoad: () => void
}) {
  return (
    <Card className="border-l-4 border-l-blue-500">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={onToggle} className="p-1">
              {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </Button>
            <div>
              <h3 className="font-semibold text-sm">{example.title}</h3>
              <p className="text-xs text-gray-600">{example.description}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs">
              {example.conversionType.replace(/_/g, "→")}
            </Badge>
            <Button size="sm" onClick={onLoad} className="text-xs">
              <Play className="w-3 h-3 mr-1" />
              Load
            </Button>
          </div>
        </div>
      </CardHeader>

      {isExpanded && (
        <CardContent className="pt-0">
          <div className="space-y-4">
            {/* Original vs Converted */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-medium text-sm mb-2">Original Automaton</h4>
                <TransitionTable automaton={example.originalAutomaton} highlightedStates={[]} />
              </div>
              <div>
                <h4 className="font-medium text-sm mb-2">Converted Automaton</h4>
                <TransitionTable automaton={example.convertedAutomaton} highlightedStates={[]} />
              </div>
            </div>

            {/* Conversion Steps */}
            <div>
              <h4 className="font-medium text-sm mb-3">Key Conversion Steps</h4>
              <div className="space-y-2">
                {example.steps.map((step) => (
                  <div key={step.stepNumber} className="border rounded-lg p-3 bg-gray-50">
                    <div className="flex items-start gap-3">
                      <Badge variant="outline" className="text-xs mt-0.5">
                        {step.stepNumber}
                      </Badge>
                      <div className="flex-1">
                        <h5 className="font-medium text-sm">{step.description}</h5>
                        <p className="text-xs text-gray-600 mt-1">{step.explanation}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      )}
    </Card>
  )
}
