"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ChevronLeft, ChevronRight, RotateCcw } from "lucide-react"
import { TransitionTable } from "./transition-table"
import { AutomataDiagram } from "./automata-diagram"
import type { ConversionStep } from "@/lib/types"

interface DetailedStepViewerProps {
  steps: ConversionStep[]
  currentStep: number
  onStepChange: (step: number) => void
}

export function DetailedStepViewer({ steps, currentStep, onStepChange }: DetailedStepViewerProps) {
  const [activeTab, setActiveTab] = useState("diagram")

  if (steps.length === 0) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center h-32 text-gray-500">
          No conversion steps available
        </CardContent>
      </Card>
    )
  }

  const currentStepData = steps[currentStep]

  return (
    <div className="space-y-4">
      {/* Step Navigation */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">
              Step {currentStep + 1} of {steps.length}
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => onStepChange(Math.max(0, currentStep - 1))}
                disabled={currentStep === 0}
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={() => onStepChange(0)}>
                <RotateCcw className="w-4 h-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onStepChange(Math.min(steps.length - 1, currentStep + 1))}
                disabled={currentStep === steps.length - 1}
              >
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div>
              <h3 className="font-semibold text-base">{currentStepData.description}</h3>
              <p className="text-sm text-gray-600 mt-1">{currentStepData.explanation}</p>
            </div>

            {/* Progress Bar */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs text-gray-500">
                <span>Progress</span>
                <span>{Math.round(((currentStep + 1) / steps.length) * 100)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
                />
              </div>
            </div>

            {/* Step Highlights */}
            <div className="flex flex-wrap gap-2">
              {currentStepData.newStates && currentStepData.newStates.length > 0 && (
                <div className="flex items-center gap-1">
                  <span className="text-xs text-green-700 font-medium">New States:</span>
                  {currentStepData.newStates.map((state) => (
                    <Badge key={state} variant="secondary" className="text-xs bg-green-100 text-green-800">
                      {state}
                    </Badge>
                  ))}
                </div>
              )}

              {currentStepData.highlightedStates.length > 0 && (
                <div className="flex items-center gap-1">
                  <span className="text-xs text-yellow-700 font-medium">Active:</span>
                  {currentStepData.highlightedStates.map((state) => (
                    <Badge key={state} variant="secondary" className="text-xs bg-yellow-100 text-yellow-800">
                      {state}
                    </Badge>
                  ))}
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Step Content */}
      <Card>
        <CardHeader>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="diagram">Diagram View</TabsTrigger>
              <TabsTrigger value="table">Table View</TabsTrigger>
            </TabsList>
          </Tabs>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsContent value="diagram" className="mt-0">
              <AutomataDiagram
                automaton={currentStepData.automaton}
                highlightedStates={currentStepData.highlightedStates}
                highlightedTransitions={currentStepData.highlightedTransitions}
              />
            </TabsContent>
            <TabsContent value="table" className="mt-0">
              <TransitionTable
                automaton={currentStepData.automaton}
                highlightedStates={currentStepData.highlightedStates}
              />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Algorithm Details */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Algorithm Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div>
                <span className="font-medium text-gray-700">States:</span>
                <div className="mt-1">
                  {currentStepData.automaton.states.map((state) => (
                    <Badge
                      key={state}
                      variant={currentStepData.highlightedStates.includes(state) ? "default" : "outline"}
                      className="text-xs mr-1 mb-1"
                    >
                      {state}
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <span className="font-medium text-gray-700">Final States:</span>
                <div className="mt-1">
                  {currentStepData.automaton.finalStates.map((state) => (
                    <Badge key={state} variant="secondary" className="text-xs mr-1 mb-1 bg-green-100 text-green-800">
                      {state}
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <span className="font-medium text-gray-700">Start State:</span>
                <div className="mt-1">
                  <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-800">
                    {currentStepData.automaton.startState}
                  </Badge>
                </div>
              </div>
            </div>

            {/* Transition Summary */}
            <div>
              <span className="font-medium text-gray-700">Active Transitions:</span>
              <div className="mt-2 space-y-1">
                {currentStepData.highlightedTransitions.map((trans, idx) => (
                  <div key={idx} className="text-xs bg-red-50 text-red-800 px-2 py-1 rounded">
                    {`${trans.from} --${trans.symbol === "" ? "ε" : trans.symbol}--> ${trans.to}`}
                  </div>
                ))}
                {currentStepData.highlightedTransitions.length === 0 && (
                  <span className="text-xs text-gray-500">No active transitions</span>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default DetailedStepViewer
