"use client"

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { predefinedProblems } from "@/lib/predefined-problems"
import type { ConversionMode } from "@/lib/types"

interface ProblemSelectorProps {
  selectedProblem: string
  onProblemSelect: (problem: string) => void
  mode: ConversionMode
}

export function ProblemSelector({ selectedProblem, onProblemSelect, mode }: ProblemSelectorProps) {
  // Filter problems based on the selected mode
  const availableProblems = Object.entries(predefinedProblems).filter(([_, problem]) => {
    switch (mode) {
      case "NFA_TO_DFA":
        return problem.type === "NFA"
      case "EPSILON_NFA_TO_NFA":
      case "EPSILON_NFA_TO_DFA":
        return problem.type === "EPSILON_NFA"
      default:
        return true
    }
  })

  return (
    <Select value={selectedProblem} onValueChange={onProblemSelect}>
      <SelectTrigger>
        <SelectValue placeholder="Choose a problem..." />
      </SelectTrigger>
      <SelectContent>
        {availableProblems.map(([key, problem]) => (
          <SelectItem key={key} value={key}>
            {problem.name}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  )
}
