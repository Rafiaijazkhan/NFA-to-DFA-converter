"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ChevronLeft, ChevronRight, RotateCcw, Play, Pause } from "lucide-react"
import { TransitionTable } from "./transition-table"
import { AutomataDiagram } from "./automata-diagram"
import type { ConversionStep } from "@/lib/types"

interface StepByStepViewerProps {
  steps: ConversionStep[]
  currentStep: number
  onStepChange: (step: number) => void
  isAutoPlaying: boolean
  onAutoPlayToggle: () => void
}

export function StepByStepViewer({
  steps,
  currentStep,
  onStepChange,
  isAutoPlaying,
  onAutoPlayToggle,
}: StepByStepViewerProps) {
  const [activeTab, setActiveTab] = useState("diagram")

  if (steps.length === 0) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center h-32 text-gray-500">
          No conversion steps available
        </CardContent>
      </Card>
    )
  }

  const currentStepData = steps[currentStep]

  return (
    <div className="space-y-4">
      {/* Step Navigation and Controls */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">
              Step {currentStep + 1} of {steps.length}
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => onStepChange(Math.max(0, currentStep - 1))}
                disabled={currentStep === 0}
              >
                <ChevronLeft className="w-4 h-4" />
                Previous
              </Button>

              <Button variant={isAutoPlaying ? "default" : "outline"} size="sm" onClick={onAutoPlayToggle}>
                {isAutoPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                {isAutoPlaying ? "Pause" : "Auto"}
              </Button>

              <Button variant="outline" size="sm" onClick={() => onStepChange(0)}>
                <RotateCcw className="w-4 h-4" />
                Reset
              </Button>

              <Button
                variant="outline"
                size="sm"
                onClick={() => onStepChange(Math.min(steps.length - 1, currentStep + 1))}
                disabled={currentStep === steps.length - 1}
              >
                Next
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Step Description */}
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold text-base text-blue-900 mb-2">{currentStepData.description}</h3>
              <p className="text-sm text-blue-800">{currentStepData.explanation}</p>
              {currentStepData.algorithm && (
                <div className="mt-2 p-2 bg-blue-100 rounded text-xs font-mono text-blue-900">
                  Algorithm: {currentStepData.algorithm}
                </div>
              )}
            </div>

            {/* Progress Bar */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs text-gray-500">
                <span>Conversion Progress</span>
                <span>{Math.round(((currentStep + 1) / steps.length) * 100)}% Complete</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-gradient-to-r from-blue-500 to-blue-600 h-3 rounded-full transition-all duration-500"
                  style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
                />
              </div>
            </div>

            {/* Step Highlights */}
            <div className="flex flex-wrap gap-3">
              {currentStepData.newStates && currentStepData.newStates.length > 0 && (
                <div className="flex items-center gap-2">
                  <span className="text-sm text-green-700 font-medium">New States:</span>
                  <div className="flex gap-1">
                    {currentStepData.newStates.map((state) => (
                      <Badge key={state} variant="secondary" className="text-xs bg-green-100 text-green-800">
                        {state}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {currentStepData.highlightedStates.length > 0 && (
                <div className="flex items-center gap-2">
                  <span className="text-sm text-yellow-700 font-medium">Active States:</span>
                  <div className="flex gap-1">
                    {currentStepData.highlightedStates.map((state) => (
                      <Badge key={state} variant="secondary" className="text-xs bg-yellow-100 text-yellow-800">
                        {state}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {currentStepData.highlightedTransitions.length > 0 && (
                <div className="flex items-center gap-2">
                  <span className="text-sm text-red-700 font-medium">Active Transitions:</span>
                  <div className="flex gap-1">
                    {currentStepData.highlightedTransitions.map((trans, idx) => (
                      <Badge key={idx} variant="secondary" className="text-xs bg-red-100 text-red-800">
                        {`${trans.from} --${trans.symbol === "" ? "ε" : trans.symbol}-\u003e ${trans.to}`}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Step Content with Tabs */}
      <Card>
        <CardHeader>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="diagram">Automaton Diagram</TabsTrigger>
              <TabsTrigger value="table">Transition Table</TabsTrigger>
            </TabsList>
          </Tabs>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsContent value="diagram" className="mt-0">
              <AutomataDiagram
                automaton={currentStepData.automaton}
                highlightedStates={currentStepData.highlightedStates}
                highlightedTransitions={currentStepData.highlightedTransitions}
              />
            </TabsContent>
            <TabsContent value="table" className="mt-0">
              <TransitionTable
                automaton={currentStepData.automaton}
                highlightedStates={currentStepData.highlightedStates}
              />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Detailed Algorithm Information */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Current Step Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
            <div className="space-y-2">
              <span className="font-medium text-gray-700">Current States:</span>
              <div className="flex flex-wrap gap-1">
                {currentStepData.automaton.states.map((state) => (
                  <Badge
                    key={state}
                    variant={currentStepData.highlightedStates.includes(state) ? "default" : "outline"}
                    className="text-xs"
                  >
                    {state}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <span className="font-medium text-gray-700">Final States:</span>
              <div className="flex flex-wrap gap-1">
                {currentStepData.automaton.finalStates.map((state) => (
                  <Badge key={state} variant="secondary" className="text-xs bg-green-100 text-green-800">
                    {state}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <span className="font-medium text-gray-700">Start State:</span>
              <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-800">
                {currentStepData.automaton.startState}
              </Badge>
            </div>

            <div className="space-y-2">
              <span className="font-medium text-gray-700">Alphabet:</span>
              <div className="flex flex-wrap gap-1">
                {currentStepData.automaton.alphabet.map((symbol) => (
                  <Badge key={symbol} variant="outline" className="text-xs">
                    {symbol === "" ? "ε" : symbol}
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          {/* Movement Direction Analysis */}
          {currentStepData.highlightedTransitions.length > 0 && (
            <div className="mt-4 p-3 bg-gray-50 rounded-lg">
              <h4 className="font-medium text-sm mb-2">Transition Analysis:</h4>
              <div className="space-y-1">
                {currentStepData.highlightedTransitions.map((trans, idx) => (
                  <div key={idx} className="text-xs text-gray-700">
                    <span className="font-mono bg-white px-2 py-1 rounded">
                      {`${trans.from} --${trans.symbol === "" ? "ε" : trans.symbol}-\u003e ${trans.to}`}
                    </span>
                    <span className="ml-2 text-gray-600">
                      {trans.symbol === ""
                        ? "ε-transition: Move without consuming input"
                        : `On input '${trans.symbol}': Move from ${trans.from} to ${trans.to}`}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default StepByStepViewer
