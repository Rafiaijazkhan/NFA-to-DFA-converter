"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Play, Pause, SkipForward, SkipBack } from "lucide-react"
import type { ConversionStep } from "@/lib/types"

interface StepControlsProps {
  currentStep: number
  totalSteps: number
  isAutoPlaying: boolean
  onNextStep: () => void
  onPrevStep: () => void
  onAutoPlay: () => void
  currentStepData: ConversionStep | undefined
}

export function StepControls({
  currentStep,
  totalSteps,
  isAutoPlaying,
  onNextStep,
  onPrevStep,
  onAutoPlay,
  currentStepData,
}: StepControlsProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Step-by-Step Conversion</span>
          <Badge variant="outline">
            Step {currentStep + 1} of {totalSteps}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between mb-4">
          <div className="flex gap-2">
            <Button onClick={onPrevStep} disabled={currentStep === 0} variant="outline" size="sm">
              <SkipBack className="w-4 h-4" />
            </Button>
            <Button onClick={onAutoPlay} variant={isAutoPlaying ? "default" : "outline"} size="sm">
              {isAutoPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              {isAutoPlaying ? "Pause" : "Auto Play"}
            </Button>
            <Button onClick={onNextStep} disabled={currentStep === totalSteps - 1} variant="outline" size="sm">
              <SkipForward className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {currentStepData && (
          <div className="space-y-2">
            <h4 className="font-semibold text-sm">{currentStepData.description}</h4>
            {currentStepData.explanation && <p className="text-sm text-gray-600">{currentStepData.explanation}</p>}
            {currentStepData.newStates && currentStepData.newStates.length > 0 && (
              <div className="flex gap-1 flex-wrap">
                <span className="text-xs text-gray-500">New states:</span>
                {currentStepData.newStates.map((state) => (
                  <Badge key={state} variant="secondary" className="text-xs">
                    {state}
                  </Badge>
                ))}
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
