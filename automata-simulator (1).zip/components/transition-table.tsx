"use client"

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import type { Automaton } from "@/lib/types"

interface TransitionTableProps {
  automaton: Automaton | null
  highlightedStates?: string[]
}

export function TransitionTable({ automaton, highlightedStates = [] }: TransitionTableProps) {
  if (!automaton) {
    return <div className="flex items-center justify-center h-32 text-gray-500">No automaton to display</div>
  }

  // Get all symbols from transitions
  const symbols = new Set<string>()
  Object.values(automaton.transitions).forEach((stateTransitions) => {
    Object.keys(stateTransitions).forEach((symbol) => symbols.add(symbol))
  })
  const sortedSymbols = Array.from(symbols).sort()

  return (
    <div className="overflow-auto max-h-96">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="font-semibold">State</TableHead>
            {sortedSymbols.map((symbol) => (
              <TableHead key={symbol} className="font-semibold text-center">
                {symbol === "" ? "ε" : symbol}
              </TableHead>
            ))}
            <TableHead className="font-semibold text-center">Type</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {automaton.states.map((state) => {
            const isHighlighted = highlightedStates.includes(state)
            const isStart = state === automaton.startState
            const isFinal = automaton.finalStates.includes(state)

            return (
              <TableRow key={state} className={isHighlighted ? "bg-yellow-50 border-yellow-200" : ""}>
                <TableCell className="font-medium">
                  <span className={isHighlighted ? "text-yellow-800 font-semibold" : ""}>{state}</span>
                </TableCell>
                {sortedSymbols.map((symbol) => {
                  const transitions = automaton.transitions[state]?.[symbol] || []
                  return (
                    <TableCell key={symbol} className="text-center">
                      {transitions.length > 0 ? (
                        <div className="flex flex-wrap gap-1 justify-center">
                          {transitions.map((targetState, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {targetState}
                            </Badge>
                          ))}
                        </div>
                      ) : (
                        <span className="text-gray-400">∅</span>
                      )}
                    </TableCell>
                  )
                })}
                <TableCell className="text-center">
                  <div className="flex gap-1 justify-center">
                    {isStart && (
                      <Badge variant="outline" className="text-xs">
                        Start
                      </Badge>
                    )}
                    {isFinal && (
                      <Badge variant="default" className="text-xs">
                        Final
                      </Badge>
                    )}
                    {!isStart && !isFinal && (
                      <Badge variant="secondary" className="text-xs">
                        Regular
                      </Badge>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            )
          })}
        </TableBody>
      </Table>
    </div>
  )
}
