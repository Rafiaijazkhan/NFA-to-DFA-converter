import type { Automaton, ConversionStep, ConversionMode } from "./types"

export class AutomataConverter {
  convert(automaton: Automaton, mode: ConversionMode): ConversionStep[] {
    switch (mode) {
      case "NFA_TO_DFA_SUBSET":
        return this.convertNFAToDFASubset(automaton)
      case "NFA_TO_DFA_POWERSET":
        return this.convertNFAToDFAPowerset(automaton)
      case "EPSILON_NFA_TO_NFA_CLOSURE":
        return this.convertEpsilonNFAToNFAClosure(automaton)
      case "EPSILON_NFA_TO_DFA_DIRECT":
        return this.convertEpsilonNFAToDFADirect(automaton)
      case "EPSILON_NFA_TO_DFA_TWO_PHASE":
        return this.convertEpsilonNFAToDFATwoPhase(automaton)
      case "NFA_MINIMIZE_DFA":
        return this.convertNFAToMinimalDFA(automaton)
      case "DFA_TO_REGEX":
        return this.convertDFAToRegex(automaton)
      case "REGEX_TO_NFA":
        return this.convertRegexToNFA(automaton)
      case "NFA_UNION":
        return this.createNFAUnion(automaton)
      case "NFA_INTERSECTION":
        return this.createNFAIntersection(automaton)
      default:
        return []
    }
  }

  private convertNFAToDFASubset(nfa: Automaton): ConversionStep[] {
    const steps: ConversionStep[] = []
    const dfaStates: string[] = []
    const dfaTransitions: Record<string, Record<string, string[]>> = {}
    const dfaFinalStates: string[] = []
    const stateQueue: string[][] = []
    const processedStates = new Set<string>()

    // Step 1: Initialize with start state
    const startStateSet = [nfa.startState]
    const startStateName = `{${startStateSet.join(",")}}`
    dfaStates.push(startStateName)
    stateQueue.push(startStateSet)

    if (startStateSet.some((state) => nfa.finalStates.includes(state))) {
      dfaFinalStates.push(startStateName)
    }

    steps.push({
      stepNumber: 1,
      description: "Initialize DFA with start state",
      explanation: `Create initial DFA state from NFA start state: ${startStateName}. This represents the set of NFA states we can be in initially.`,
      automaton: {
        ...nfa,
        states: [startStateName],
        transitions: {},
        finalStates: dfaFinalStates.includes(startStateName) ? [startStateName] : [],
        type: "DFA",
      },
      highlightedStates: [startStateName],
      highlightedTransitions: [],
      newStates: [startStateName],
      algorithm: "Subset Construction: δ'(q₀) = {q₀}",
    })

    let stepNumber = 2

    // Process each state in the queue
    while (stateQueue.length > 0) {
      const currentStateSet = stateQueue.shift()!
      const currentStateName = `{${currentStateSet.join(",")}}`

      if (processedStates.has(currentStateName)) continue
      processedStates.add(currentStateName)

      dfaTransitions[currentStateName] = {}

      // For each symbol in the alphabet
      for (const symbol of nfa.alphabet) {
        const targetStates = new Set<string>()

        // Collect all states reachable from current state set on this symbol
        for (const state of currentStateSet) {
          const transitions = nfa.transitions[state]?.[symbol] || []
          transitions.forEach((target) => targetStates.add(target))
        }

        if (targetStates.size > 0) {
          const targetStateArray = Array.from(targetStates).sort()
          const targetStateName = `{${targetStateArray.join(",")}}`

          dfaTransitions[currentStateName][symbol] = [targetStateName]

          // Add new state if not already processed
          if (!dfaStates.includes(targetStateName)) {
            dfaStates.push(targetStateName)
            stateQueue.push(targetStateArray)

            // Check if it's a final state
            if (targetStateArray.some((state) => nfa.finalStates.includes(state))) {
              dfaFinalStates.push(targetStateName)
            }

            steps.push({
              stepNumber: stepNumber++,
              description: `Create new DFA state: ${targetStateName}`,
              explanation: `From state ${currentStateName} on input '${symbol}', we can reach NFA states {${targetStateArray.join(", ")}}. Since this combination doesn't exist yet, we create a new DFA state.`,
              automaton: {
                ...nfa,
                states: [...dfaStates],
                transitions: { ...dfaTransitions },
                finalStates: [...dfaFinalStates],
                type: "DFA",
              },
              highlightedStates: [targetStateName],
              highlightedTransitions: [
                {
                  from: currentStateName,
                  to: targetStateName,
                  symbol: symbol,
                },
              ],
              newStates: [targetStateName],
              algorithm: `δ'(${currentStateName}, ${symbol}) = ${targetStateName}`,
            })
          }
        }
      }
    }

    // Final step
    steps.push({
      stepNumber: stepNumber,
      description: "Subset Construction Complete",
      explanation: `NFA to DFA conversion using subset construction is complete. The final DFA has ${dfaStates.length} states compared to ${nfa.states.length} NFA states.`,
      automaton: {
        ...nfa,
        states: dfaStates,
        transitions: dfaTransitions,
        startState: startStateName,
        finalStates: dfaFinalStates,
        type: "DFA",
      },
      highlightedStates: dfaFinalStates,
      highlightedTransitions: [],
      newStates: [],
      algorithm: "Subset Construction Algorithm Complete",
    })

    return steps
  }

  private convertNFAToDFAPowerset(nfa: Automaton): ConversionStep[] {
    const steps: ConversionStep[] = []

    steps.push({
      stepNumber: 1,
      description: "Powerset Method: Generate all possible state combinations",
      explanation:
        "Using powerset method to systematically generate all possible DFA states from NFA state combinations.",
      automaton: { ...nfa },
      highlightedStates: nfa.states,
      highlightedTransitions: [],
      newStates: [],
      algorithm: "Powerset Construction: P(Q) = 2^|Q|",
    })

    // Simplified powerset approach - similar to subset but different explanation
    return this.convertNFAToDFASubset(nfa).map((step) => ({
      ...step,
      algorithm: step.algorithm?.replace("Subset", "Powerset"),
    }))
  }

  private convertEpsilonNFAToNFAClosure(epsilonNfa: Automaton): ConversionStep[] {
    const steps: ConversionStep[] = []
    let stepNumber = 1

    // Step 1: Compute epsilon closures
    const epsilonClosures: Record<string, Set<string>> = {}
    for (const state of epsilonNfa.states) {
      epsilonClosures[state] = this.computeEpsilonClosure(epsilonNfa, [state])
    }

    steps.push({
      stepNumber: stepNumber++,
      description: "Compute ε-closures for all states",
      explanation: `Calculate ε-closure for each state. ε-closure(q) includes q and all states reachable from q via ε-transitions only.`,
      automaton: { ...epsilonNfa },
      highlightedStates: epsilonNfa.states,
      highlightedTransitions: this.getEpsilonTransitions(epsilonNfa),
      newStates: [],
      algorithm: "ε-closure(q) = {q} ∪ {states reachable via ε*}",
    })

    // Build NFA transitions
    const nfaTransitions: Record<string, Record<string, string[]>> = {}
    for (const state of epsilonNfa.states) {
      nfaTransitions[state] = {}
      for (const symbol of epsilonNfa.alphabet.filter((s) => s !== "")) {
        const targetStates = new Set<string>()
        for (const epsilonState of epsilonClosures[state]) {
          const directTransitions = epsilonNfa.transitions[epsilonState]?.[symbol] || []
          for (const target of directTransitions) {
            for (const epsilonTarget of epsilonClosures[target]) {
              targetStates.add(epsilonTarget)
            }
          }
        }
        if (targetStates.size > 0) {
          nfaTransitions[state][symbol] = Array.from(targetStates).sort()
        }
      }
    }

    steps.push({
      stepNumber: stepNumber++,
      description: "Build NFA transitions (eliminate ε-transitions)",
      explanation: `For each state and symbol, compute new transitions: δ'(q,a) = ε-closure(δ(ε-closure(q),a)).`,
      automaton: {
        ...epsilonNfa,
        transitions: nfaTransitions,
        alphabet: epsilonNfa.alphabet.filter((s) => s !== ""),
        type: "NFA",
      },
      highlightedStates: [],
      highlightedTransitions: [],
      newStates: [],
      algorithm: "δ'(q,a) = ε-closure(δ(ε-closure(q),a))",
    })

    // Determine final states
    const nfaFinalStates: string[] = []
    for (const state of epsilonNfa.states) {
      if (Array.from(epsilonClosures[state]).some((s) => epsilonNfa.finalStates.includes(s))) {
        nfaFinalStates.push(state)
      }
    }

    steps.push({
      stepNumber: stepNumber,
      description: "ε-NFA to NFA conversion complete",
      explanation: `A state is final if its ε-closure contains any original final state. The ε-NFA has been successfully converted to an equivalent NFA.`,
      automaton: {
        ...epsilonNfa,
        transitions: nfaTransitions,
        alphabet: epsilonNfa.alphabet.filter((s) => s !== ""),
        finalStates: nfaFinalStates,
        type: "NFA",
      },
      highlightedStates: nfaFinalStates,
      highlightedTransitions: [],
      newStates: [],
      algorithm: "ε-closure elimination complete",
    })

    return steps
  }

  private convertEpsilonNFAToDFADirect(epsilonNfa: Automaton): ConversionStep[] {
    const steps: ConversionStep[] = []

    steps.push({
      stepNumber: 1,
      description: "Direct ε-NFA to DFA conversion",
      explanation: "Converting ε-NFA directly to DFA without intermediate NFA step using extended subset construction.",
      automaton: { ...epsilonNfa },
      highlightedStates: epsilonNfa.states,
      highlightedTransitions: [],
      newStates: [],
      algorithm: "Extended Subset Construction with ε-closures",
    })

    // For simplicity, use the two-phase approach but with different descriptions
    return this.convertEpsilonNFAToDFATwoPhase(epsilonNfa)
  }

  private convertEpsilonNFAToDFATwoPhase(epsilonNfa: Automaton): ConversionStep[] {
    // First convert ε-NFA to NFA
    const nfaSteps = this.convertEpsilonNFAToNFAClosure(epsilonNfa)
    const nfa = nfaSteps[nfaSteps.length - 1].automaton

    // Then convert NFA to DFA
    const dfaSteps = this.convertNFAToDFASubset(nfa)

    // Combine steps
    const combinedSteps = [
      ...nfaSteps.map((step) => ({
        ...step,
        description: `[Phase 1: ε-NFA → NFA] ${step.description}`,
      })),
      ...dfaSteps.map((step, index) => ({
        ...step,
        stepNumber: step.stepNumber + nfaSteps.length,
        description: `[Phase 2: NFA → DFA] ${step.description}`,
      })),
    ]

    return combinedSteps
  }

  private convertNFAToMinimalDFA(nfa: Automaton): ConversionStep[] {
    const steps = this.convertNFAToDFASubset(nfa)

    // Add minimization step
    const finalDFA = steps[steps.length - 1].automaton
    steps.push({
      stepNumber: steps.length + 1,
      description: "Minimize DFA using state equivalence",
      explanation: "Apply DFA minimization algorithm to reduce the number of states by merging equivalent states.",
      automaton: finalDFA, // Simplified - would need actual minimization
      highlightedStates: [],
      highlightedTransitions: [],
      newStates: [],
      algorithm: "DFA Minimization: Merge equivalent states",
    })

    return steps
  }

  private convertDFAToRegex(automaton: Automaton): ConversionStep[] {
    const steps: ConversionStep[] = []

    steps.push({
      stepNumber: 1,
      description: "Convert DFA to Regular Expression",
      explanation: "Using state elimination method to convert DFA to equivalent regular expression.",
      automaton: { ...automaton },
      highlightedStates: automaton.states,
      highlightedTransitions: [],
      newStates: [],
      algorithm: "State Elimination Method",
    })

    return steps
  }

  private convertRegexToNFA(automaton: Automaton): ConversionStep[] {
    const steps: ConversionStep[] = []

    steps.push({
      stepNumber: 1,
      description: "Convert Regular Expression to NFA",
      explanation: "Using Thompson's construction to build NFA from regular expression.",
      automaton: { ...automaton },
      highlightedStates: automaton.states,
      highlightedTransitions: [],
      newStates: [],
      algorithm: "Thompson's Construction",
    })

    return steps
  }

  private createNFAUnion(automaton: Automaton): ConversionStep[] {
    const steps: ConversionStep[] = []

    steps.push({
      stepNumber: 1,
      description: "Create NFA for Union of Languages",
      explanation: "Construct NFA that accepts the union of two languages using ε-transitions.",
      automaton: { ...automaton },
      highlightedStates: automaton.states,
      highlightedTransitions: [],
      newStates: [],
      algorithm: "Union Construction: L₁ ∪ L₂",
    })

    return steps
  }

  private createNFAIntersection(automaton: Automaton): ConversionStep[] {
    const steps: ConversionStep[] = []

    steps.push({
      stepNumber: 1,
      description: "Create NFA for Intersection of Languages",
      explanation: "Construct NFA that accepts the intersection of two languages using product construction.",
      automaton: { ...automaton },
      highlightedStates: automaton.states,
      highlightedTransitions: [],
      newStates: [],
      algorithm: "Intersection Construction: L₁ ∩ L₂",
    })

    return steps
  }

  private computeEpsilonClosure(automaton: Automaton, states: string[]): Set<string> {
    const closure = new Set<string>(states)
    const stack = [...states]

    while (stack.length > 0) {
      const current = stack.pop()!
      const epsilonTransitions = automaton.transitions[current]?.[""] || []

      for (const target of epsilonTransitions) {
        if (!closure.has(target)) {
          closure.add(target)
          stack.push(target)
        }
      }
    }

    return closure
  }

  private getEpsilonTransitions(automaton: Automaton): Array<{ from: string; to: string; symbol: string }> {
    const epsilonTransitions: Array<{ from: string; to: string; symbol: string }> = []

    for (const [fromState, transitions] of Object.entries(automaton.transitions)) {
      const epsilonTargets = transitions[""] || []
      for (const toState of epsilonTargets) {
        epsilonTransitions.push({ from: fromState, to: toState, symbol: "" })
      }
    }

    return epsilonTransitions
  }
}
