import type { Automaton } from "./types"

export const predefinedProblems: Record<string, Automaton> = {
  // NFA Problems (5 problems)
  "nfa-ending-01": {
    name: "NFA #1 - Binary strings ending in '01'",
    states: ["q0", "q1", "q2"],
    alphabet: ["0", "1"],
    transitions: {
      q0: {
        "0": ["q0", "q1"],
        "1": ["q0"],
      },
      q1: {
        "0": [],
        "1": ["q2"],
      },
      q2: {
        "0": [],
        "1": [],
      },
    },
    startState: "q0",
    finalStates: ["q2"],
    type: "NFA",
  },

  "nfa-substring-101": {
    name: "NFA #2 - Contains substring '101'",
    states: ["q0", "q1", "q2", "q3"],
    alphabet: ["0", "1"],
    transitions: {
      q0: {
        "0": ["q0"],
        "1": ["q0", "q1"],
      },
      q1: {
        "0": ["q2"],
        "1": ["q0"],
      },
      q2: {
        "0": ["q0"],
        "1": ["q3"],
      },
      q3: {
        "0": ["q3"],
        "1": ["q3"],
      },
    },
    startState: "q0",
    finalStates: ["q3"],
    type: "NFA",
  },

  "nfa-even-0s": {
    name: "NFA #3 - Even number of 0s",
    states: ["q0", "q1", "q2"],
    alphabet: ["0", "1"],
    transitions: {
      q0: {
        "0": ["q1", "q2"],
        "1": ["q0"],
      },
      q1: {
        "0": ["q0"],
        "1": ["q1"],
      },
      q2: {
        "0": ["q0"],
        "1": ["q2"],
      },
    },
    startState: "q0",
    finalStates: ["q0"],
    type: "NFA",
  },

  "nfa-starts-ends-same": {
    name: "NFA #4 - Starts and ends with same symbol",
    states: ["q0", "q1", "q2", "q3", "q4"],
    alphabet: ["a", "b"],
    transitions: {
      q0: {
        a: ["q1"],
        b: ["q3"],
      },
      q1: {
        a: ["q1", "q2"],
        b: ["q1"],
      },
      q2: {
        a: [],
        b: [],
      },
      q3: {
        a: ["q3"],
        b: ["q3", "q4"],
      },
      q4: {
        a: [],
        b: [],
      },
    },
    startState: "q0",
    finalStates: ["q2", "q4"],
    type: "NFA",
  },

  "nfa-length-multiple-3": {
    name: "NFA #5 - Length is multiple of 3",
    states: ["q0", "q1", "q2"],
    alphabet: ["0", "1"],
    transitions: {
      q0: {
        "0": ["q0", "q1"],
        "1": ["q0", "q1"],
      },
      q1: {
        "0": ["q2"],
        "1": ["q2"],
      },
      q2: {
        "0": ["q0"],
        "1": ["q0"],
      },
    },
    startState: "q0",
    finalStates: ["q0"],
    type: "NFA",
  },

  // Epsilon-NFA Problems (5 problems)
  "epsilon-nfa-optional-a": {
    name: "ε-NFA #1 - Optional 'a' in middle (b*ab*|b*b*)",
    states: ["q0", "q1", "q2", "q3"],
    alphabet: ["a", "b", ""],
    transitions: {
      q0: {
        b: ["q0"],
        "": ["q1", "q3"],
      },
      q1: {
        a: ["q2"],
      },
      q2: {
        b: ["q2"],
        "": ["q3"],
      },
      q3: {
        b: ["q3"],
      },
    },
    startState: "q0",
    finalStates: ["q3"],
    type: "EPSILON_NFA",
  },

  "epsilon-nfa-union": {
    name: "ε-NFA #2 - Union (a*b* | c*d*)",
    states: ["q0", "q1", "q2", "q3", "q4", "q5"],
    alphabet: ["a", "b", "c", "d", ""],
    transitions: {
      q0: {
        "": ["q1", "q3"],
      },
      q1: {
        a: ["q1"],
        "": ["q2"],
      },
      q2: {
        b: ["q2"],
        "": ["q5"],
      },
      q3: {
        c: ["q3"],
        "": ["q4"],
      },
      q4: {
        d: ["q4"],
        "": ["q5"],
      },
      q5: {},
    },
    startState: "q0",
    finalStates: ["q5"],
    type: "EPSILON_NFA",
  },

  "epsilon-nfa-concatenation": {
    name: "ε-NFA #3 - Concatenation (ab*cd*)",
    states: ["q0", "q1", "q2", "q3", "q4"],
    alphabet: ["a", "b", "c", "d", ""],
    transitions: {
      q0: {
        a: ["q1"],
      },
      q1: {
        b: ["q1"],
        "": ["q2"],
      },
      q2: {
        c: ["q3"],
      },
      q3: {
        d: ["q3"],
        "": ["q4"],
      },
      q4: {},
    },
    startState: "q0",
    finalStates: ["q4"],
    type: "EPSILON_NFA",
  },

  "epsilon-nfa-kleene-star": {
    name: "ε-NFA #4 - Kleene Star (ab)*",
    states: ["q0", "q1", "q2"],
    alphabet: ["a", "b", ""],
    transitions: {
      q0: {
        "": ["q1", "q2"],
      },
      q1: {
        a: ["q1"],
        b: ["q1"],
        "": ["q2"],
      },
      q2: {
        "": ["q0"],
      },
    },
    startState: "q0",
    finalStates: ["q2"],
    type: "EPSILON_NFA",
  },

  "epsilon-nfa-complex": {
    name: "ε-NFA #5 - Complex Multi-Path (a|b)*c(d|ε)",
    states: ["q0", "q1", "q2", "q3", "q4", "q5"],
    alphabet: ["a", "b", "c", "d", ""],
    transitions: {
      q0: {
        "": ["q1"],
        a: ["q0"],
        b: ["q0"],
      },
      q1: {
        a: ["q1"],
        b: ["q1"],
        c: ["q2"],
        "": ["q2"],
      },
      q2: {
        c: ["q3"],
      },
      q3: {
        "": ["q4", "q5"],
      },
      q4: {
        d: ["q5"],
      },
      q5: {},
    },
    startState: "q0",
    finalStates: ["q5"],
    type: "EPSILON_NFA",
  },
}
