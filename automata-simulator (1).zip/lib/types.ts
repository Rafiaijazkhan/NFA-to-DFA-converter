export interface Automaton {
  states: string[]
  alphabet: string[]
  transitions: Record<string, Record<string, string[]>>
  startState: string
  finalStates: string[]
  type: "NFA" | "DFA" | "EPSILON_NFA"
  name?: string
}

export interface ConversionStep {
  stepNumber: number
  description: string
  explanation: string
  automaton: Automaton
  highlightedStates: string[]
  highlightedTransitions: Array<{ from: string; to: string; symbol: string }>
  newStates?: string[]
  algorithm?: string
}

export type ConversionMode =
  | "NFA_TO_DFA_SUBSET"
  | "NFA_TO_DFA_POWERSET"
  | "EPSILON_NFA_TO_NFA_CLOSURE"
  | "EPSILON_NFA_TO_DFA_DIRECT"
  | "EPSILON_NFA_TO_DFA_TWO_PHASE"
  | "NFA_MINIMIZE_DFA"
  | "DFA_TO_REGEX"
  | "REGEX_TO_NFA"
  | "NFA_UNION"
  | "NFA_INTERSECTION"
